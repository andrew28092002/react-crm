# react-crm

Выполненно на React.js с использованием react-router   
Взаимодействие с api  

[Page](https://andrew28092002.github.io/react-crm/)
