const testRequests = [
  {
    name: "Дмитрий Сергеев",
    email: "dmitriy@gmail.com",
    phone: "89458543499",
    product: "course-php",
  },
  {
    name: "Сергей Дмитриев",
    email: "sergei@gmail.com",
    phone: "89434789324",
    product: "course-js",
  },
  {
    name: "Лука Модрич",
    email: "lukamodric@gmail.com",
    phone: "89451233479",
    product: "course-vue",
  },
  {
    name: "Карим Бензема",
    email: "benz@gmail.com",
    phone: "84351233499",
    product: "course-js",
  },
  {
    name: "Артемий Сергеев",
    email: "artemiy@gmail.com",
    phone: "89453433499",
    product: "course-vue",
  },
];

const randomValue = ()=>{
  return testRequests[Math.floor(Math.random()*(testRequests.length-1))]
}

export default randomValue;
